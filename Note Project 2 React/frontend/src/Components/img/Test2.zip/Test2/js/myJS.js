const URL="https://restcountries.com/v3.1/all";

$(async()=>{

  data = await $.get(URL);
  console.log(data);
});

let totalPopulation = 0;

$("#allButton").on("click", () => {
  let countries = "";
  data.forEach((country) => {
    countries += country.name.common + "<br>";
  });
  $("#container").html(countries);
});


const getCountry = (text)=>{
  let result="";
  for (let counter=0;counter<data.length;counter++){
      if (data[counter].name.common){
          if (data[counter].name.common[0]==text){
              result+=`<td>${data[counter].name.common}</td>`
          }
      }
  }
  result+="</tr>";
  return result;
}

const filterCountries = () => {
  const searchText = $("#addedText").val().toLowerCase();
  let countries = "";
  const filteredData = data.filter((country) => {
    return country.name.common.toLowerCase().includes(searchText);
  });
  filteredData.forEach((country) => {
    countries += country.name.common + "<br>";
  });
  $("#container").html(countries);
};

$("#search").on("click", filterCountries);
